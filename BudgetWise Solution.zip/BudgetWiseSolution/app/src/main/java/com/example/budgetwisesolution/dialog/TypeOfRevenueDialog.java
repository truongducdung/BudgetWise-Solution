package com.example.budgetwisesolution.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.example.budgetwisesolution.R;
import com.example.budgetwisesolution.entity.TypeOfRevenue;
import com.example.budgetwisesolution.ui.Collect.TypeOfRevenueFragment;
import com.example.budgetwisesolution.ui.Collect.TypeOfRevenueViewModel;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class TypeOfRevenueDialog {
    private TypeOfRevenueViewModel mViewModel;
    private LayoutInflater mLayoutInflater;
    private AlertDialog mDialog;

    private TextInputEditText etId, etName;
    private boolean mEditMode;

    public TypeOfRevenueDialog(Context context, TypeOfRevenueFragment fragment, TypeOfRevenue ... typeOfRevenue) {
        mViewModel = fragment.getViewModel();
        mLayoutInflater = LayoutInflater.from(context);
        View view = mLayoutInflater.inflate(R.layout.dialog_type_of_revenue,null);
        etId = view.findViewById(R.id.etId);
        etName = view.findViewById(R.id.etName);
        if(typeOfRevenue != null && typeOfRevenue.length>0){
            etId.setText(String.valueOf(typeOfRevenue[0].tor));
            etName.setText(typeOfRevenue[0].name);
            mEditMode = true;
        }else {
            mEditMode = false;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setView(view)
                .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mDialog.dismiss();
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        TypeOfRevenue tor = new TypeOfRevenue();
                        tor.name = Objects.requireNonNull(etName.getText()).toString();
                        if(mEditMode ){
                            tor.tor =Integer.parseInt(Objects.requireNonNull(etId.getText()).toString()) ;
                            mViewModel.update(tor);
                        }else {
                            mViewModel.insert(tor);
                            Toast.makeText(context, "Type of Revenue saved", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        mDialog = builder.create();
    }
    public void show(){
        mDialog.show();
    }
}
