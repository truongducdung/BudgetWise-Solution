package com.example.budgetwisesolution.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.budgetwisesolution.ui.Collect.RevenueFragment;
import com.example.budgetwisesolution.ui.Collect.TypeOfRevenueFragment;
import com.example.budgetwisesolution.ui.Spend.CostsFragment;
import com.example.budgetwisesolution.ui.Spend.ExpenditureFragment;

public class SpendViewPager2Adaptor extends FragmentStateAdapter {
    public SpendViewPager2Adaptor(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment;
        if (position == 0){
            fragment = ExpenditureFragment.newInstance();
        }else {
            fragment = CostsFragment.newInstance();
        }
        return fragment;
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
