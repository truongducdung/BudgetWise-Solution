package com.example.budgetwisesolution.ui.Spend;

import androidx.lifecycle.ViewModel;

public class ExpenditureViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}