package com.example.budgetwisesolution.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class TypeOfRevenue {
    @PrimaryKey(autoGenerate = true)
    public int tor;
    @ColumnInfo(name = "name")
    public String name;
}
