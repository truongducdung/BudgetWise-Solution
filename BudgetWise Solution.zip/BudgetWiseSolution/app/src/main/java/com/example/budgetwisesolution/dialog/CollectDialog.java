package com.example.budgetwisesolution.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.lifecycle.Observer;

import com.example.budgetwisesolution.R;
import com.example.budgetwisesolution.adapter.CollectSpinnerAdapter;
import com.example.budgetwisesolution.entity.Collect;
import com.example.budgetwisesolution.entity.TypeOfRevenue;
import com.example.budgetwisesolution.ui.Collect.RevenueFragment;
import com.example.budgetwisesolution.ui.Collect.RevenueViewModel;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;
import java.util.Objects;

public class CollectDialog {
    private RevenueViewModel mViewModel;
    private LayoutInflater mLayoutInflater;
    private AlertDialog mDialog;

    private TextInputEditText etId, etName, etAmount, etNote;
    private Spinner spType;
    private boolean mEditMode;
    private CollectSpinnerAdapter mAdapter;

    public CollectDialog(Context context, RevenueFragment fragment, Collect ... collect) {
        mViewModel = fragment.getViewModel();
        mLayoutInflater = LayoutInflater.from(context);
        View view = mLayoutInflater.inflate(R.layout.dialog_collect,null);
        etId = view.findViewById(R.id.etId);
        etName = view.findViewById(R.id.etName);
        etAmount = view.findViewById(R.id.etAmount);
        etNote = view.findViewById(R.id.etNote);
        spType = view.findViewById(R.id.spType);
        mAdapter = new CollectSpinnerAdapter(fragment.getActivity());
        mViewModel.getAllTypeOfRevenue().observe(fragment.getActivity(), new Observer<List<TypeOfRevenue>>() {
            @Override
            public void onChanged(List<TypeOfRevenue> typeOfRevenues) {
                mAdapter.setList(typeOfRevenues);
            }
        });
        spType.setAdapter(mAdapter);
        if(collect != null && collect.length>0){
            etId.setText("" +collect[0].cid);
            etName.setText(collect[0].name);
            etAmount.setText(""+collect[0].money);
            etNote.setText(collect[0].note);
            mEditMode = true;
        }else {
            mEditMode = false;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setView(view)
                .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mDialog.dismiss();
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Collect tor = new Collect();
                        tor.name = Objects.requireNonNull(etName.getText()).toString();
                        tor.money = Float.parseFloat(etAmount.getText().toString());
                        tor.note = etNote.getText().toString();
                        tor.cid =((Collect) mAdapter.getItem(spType.getSelectedItemPosition())).torid;
                        if(mEditMode ){
                            tor.cid =Integer.parseInt((etId.getText()).toString()) ;
                            mViewModel.update(tor);
                        }else {
                            mViewModel.insert(tor);
                            Toast.makeText(context, "Type of Revenue saved", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        mDialog = builder.create();
    }
    public void show(){
        mDialog.show();
    }
}
