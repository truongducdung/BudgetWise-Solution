package com.example.budgetwisesolution.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Collect {
    @PrimaryKey(autoGenerate = true)
    public int cid;
    @ColumnInfo(name = "torid")
    public int torid;
    @ColumnInfo(name = "name")
    public String name;
    @ColumnInfo(name = "money")
    public float money;
    @ColumnInfo(name = "note")
    public String note;

}
