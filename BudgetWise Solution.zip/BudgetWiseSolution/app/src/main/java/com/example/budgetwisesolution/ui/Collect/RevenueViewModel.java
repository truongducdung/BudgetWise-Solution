package com.example.budgetwisesolution.ui.Collect;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.budgetwisesolution.entity.Collect;
import com.example.budgetwisesolution.entity.TypeOfRevenue;
import com.example.budgetwisesolution.repository.CollectRepository;
import com.example.budgetwisesolution.repository.TypeOfRevenueRepository;

import java.util.List;

public class RevenueViewModel extends AndroidViewModel {
    private CollectRepository mCollectRepository;
    private TypeOfRevenueRepository mTypeOfRevenueRepository;
    private LiveData<List<Collect>> mAllCollect;
    private LiveData<List<TypeOfRevenue>> mAllTypeOfRevenue;
    public RevenueViewModel(@NonNull Application application) {
        super(application);
        mCollectRepository = new CollectRepository(application);
        mAllCollect = mCollectRepository.getAllCollect();
        mTypeOfRevenueRepository = new TypeOfRevenueRepository(application);
        mAllTypeOfRevenue = mTypeOfRevenueRepository.getAllTypeOfRevenue();
    }
    public  LiveData<List<TypeOfRevenue>> getAllTypeOfRevenue(){
        return mAllTypeOfRevenue;
    }
    public LiveData<List<Collect>> getAllCollect() {
        return mAllCollect;
    }
    public void insert(Collect collect){
        mCollectRepository.insert(collect);
    }

    public void delete(Collect collect){
        mCollectRepository.delete((collect));
    }
    public void update(Collect collect){
        mCollectRepository.update(collect);
    }
}