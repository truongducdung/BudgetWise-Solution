package com.example.budgetwisesolution.dao;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.budgetwisesolution.entity.Collect;
import com.example.budgetwisesolution.entity.TypeOfRevenue;

@Database(entities = {TypeOfRevenue.class, Collect.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    public abstract TypeOfRevenueDao typeOfRevenueDao();
    public abstract CollectDao collectDao();
    public static AppDatabase INSTANCE;

    private static RoomDatabase.Callback callback= new Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);

            new PopulateData(INSTANCE).execute();
        }
    };

    public static AppDatabase getDatabase(final Context context){
        if (INSTANCE == null){
            synchronized (AppDatabase.class){
                INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "personal_db")
                        .fallbackToDestructiveMigration()
                        .addCallback(callback)
                        .build();
            }
        }
        return INSTANCE;
    }
    public static class PopulateData extends AsyncTask<Void, Void, Void>{
        private TypeOfRevenueDao typeOfRevenueDao;
        private CollectDao collectDao;

        public PopulateData(AppDatabase db) {
            typeOfRevenueDao = db.typeOfRevenueDao();
            collectDao = db.collectDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            String[] typeofrevenue = new String[]{"Salary", "Money Bonus", "Invest"};
            for (String it: typeofrevenue) {
                TypeOfRevenue tor = new TypeOfRevenue();
                tor.name = it;
                typeOfRevenueDao.insert(tor);
            }
            Collect collect = new Collect();
            collect.name = "Luong thang 1";
            collect.money = 3000;
            collect.torid = 2;
            collect.note = "";
            collectDao.insert(collect);
            Log.d("BudgetWise Solution: ", "insert data ");
            return null;
        }
    }
}
