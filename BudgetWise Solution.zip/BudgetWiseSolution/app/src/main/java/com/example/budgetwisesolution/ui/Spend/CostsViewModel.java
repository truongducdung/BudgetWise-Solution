package com.example.budgetwisesolution.ui.Spend;

import androidx.lifecycle.ViewModel;

public class CostsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}