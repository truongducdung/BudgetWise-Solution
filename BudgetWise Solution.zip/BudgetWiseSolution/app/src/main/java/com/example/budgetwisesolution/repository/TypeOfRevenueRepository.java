package com.example.budgetwisesolution.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.budgetwisesolution.dao.AppDatabase;
import com.example.budgetwisesolution.dao.TypeOfRevenueDao;
import com.example.budgetwisesolution.entity.TypeOfRevenue;

import java.util.List;

public class TypeOfRevenueRepository {
    private TypeOfRevenueDao mtypeOfRevenueDao;
    private LiveData<List<TypeOfRevenue>> mAllTypeOfRevenue;

    public TypeOfRevenueRepository(Application application) {
        this.mtypeOfRevenueDao = AppDatabase.getDatabase(application).typeOfRevenueDao();
        mAllTypeOfRevenue = mtypeOfRevenueDao.findAll();
    }

    public LiveData<List<TypeOfRevenue>> getAllTypeOfRevenue() {
        return mAllTypeOfRevenue;
    }
    public void insert(TypeOfRevenue typeOfRevenue){
        new InsertAsyncTask(mtypeOfRevenueDao).execute(typeOfRevenue);
    }
    public void delete(TypeOfRevenue typeOfRevenue){
        new DeleteAsyncTask(mtypeOfRevenueDao).execute(typeOfRevenue);
    }
    public void update(TypeOfRevenue typeOfRevenue){
        new UpdateAsyncTask(mtypeOfRevenueDao).execute(typeOfRevenue);
    }
    class UpdateAsyncTask extends AsyncTask<TypeOfRevenue, Void, Void>{
        private TypeOfRevenueDao mTypeOfRevenueDao;
        public UpdateAsyncTask(TypeOfRevenueDao typeOfRevenueDao){
            this.mTypeOfRevenueDao = typeOfRevenueDao;
        }
        @Override
        protected Void doInBackground(TypeOfRevenue... typeOfRevenues) {
            mtypeOfRevenueDao.update(typeOfRevenues[0]);
            return null;
        }
    }
    class InsertAsyncTask extends AsyncTask<TypeOfRevenue, Void, Void>{
        private TypeOfRevenueDao mTypeOfRevenueDao;
        public InsertAsyncTask(TypeOfRevenueDao typeOfRevenueDao){
            this.mTypeOfRevenueDao = typeOfRevenueDao;
        }
        @Override
        protected Void doInBackground(TypeOfRevenue... typeOfRevenues) {
            mtypeOfRevenueDao.insert(typeOfRevenues[0]);
            return null;
        }
    }

    class DeleteAsyncTask extends AsyncTask<TypeOfRevenue, Void, Void>{
        private TypeOfRevenueDao mTypeOfRevenueDao;
        public DeleteAsyncTask(TypeOfRevenueDao typeOfRevenueDao){
            this.mTypeOfRevenueDao = typeOfRevenueDao;
        }
        @Override
        protected Void doInBackground(TypeOfRevenue... typeOfRevenues) {
            mtypeOfRevenueDao.delete(typeOfRevenues[0]);
            return null;
        }
    }
}
