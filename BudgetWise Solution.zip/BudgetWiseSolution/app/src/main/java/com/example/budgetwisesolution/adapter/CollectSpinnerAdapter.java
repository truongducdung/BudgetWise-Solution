package com.example.budgetwisesolution.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.budgetwisesolution.R;
import com.example.budgetwisesolution.entity.Collect;
import com.example.budgetwisesolution.entity.TypeOfRevenue;

import java.util.List;

public class CollectSpinnerAdapter extends BaseAdapter {
    private List<TypeOfRevenue> mList;
    private LayoutInflater mLayoutInflater;

    public CollectSpinnerAdapter(Context context) {
        mLayoutInflater = LayoutInflater.from(context);
    }

    public void setList(List<TypeOfRevenue> mList) {
        this.mList = mList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (mList == null )
            return 0;
        return mList.size();
    }

    @Override
    public Object getItem(int i) {
        if (mList == null)
            return null;
        return mList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        RevenueViewHolder holder;
        if (view == null){
            view = mLayoutInflater.inflate(R.layout.spinner_collect_item, null, false);
            holder = new RevenueViewHolder(view);
            view.setTag(holder);
        }else {
            holder = (RevenueViewHolder) view.getTag();
        }
        holder.tvName.setText(mList.get(i).name);
        return view;
    }
    public static class RevenueViewHolder{
        public TextView tvName;
        public RevenueViewHolder(View view){
            tvName = view.findViewById(R.id.tvNameSpinner);
        }
    }
}
