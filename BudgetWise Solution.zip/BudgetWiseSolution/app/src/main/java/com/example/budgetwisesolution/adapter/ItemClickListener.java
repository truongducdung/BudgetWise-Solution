package com.example.budgetwisesolution.adapter;

public interface ItemClickListener {
    void onItemClick(int position);
}
