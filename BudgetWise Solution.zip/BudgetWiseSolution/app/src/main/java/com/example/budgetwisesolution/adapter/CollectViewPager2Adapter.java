package com.example.budgetwisesolution.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.budgetwisesolution.ui.Collect.RevenueFragment;
import com.example.budgetwisesolution.ui.Collect.TypeOfRevenueFragment;

public class CollectViewPager2Adapter extends FragmentStateAdapter {
    public CollectViewPager2Adapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment;
        if (position == 0){
            fragment = RevenueFragment.newInstance();
        }else {
            fragment = TypeOfRevenueFragment.newInstance();
        }
        return fragment;
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
