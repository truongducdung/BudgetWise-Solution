package com.example.budgetwisesolution.ui.Collect;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.budgetwisesolution.dao.TypeOfRevenueDao;
import com.example.budgetwisesolution.entity.TypeOfRevenue;
import com.example.budgetwisesolution.repository.TypeOfRevenueRepository;

import java.util.List;

public class TypeOfRevenueViewModel extends AndroidViewModel {
    private TypeOfRevenueRepository mTypeOfRevenueRepository;
    private LiveData<List<TypeOfRevenue>> mAllTypeOfRevenue;
    public TypeOfRevenueViewModel(@NonNull Application application) {
        super(application);
        mTypeOfRevenueRepository = new TypeOfRevenueRepository(application);
        mAllTypeOfRevenue = mTypeOfRevenueRepository.getAllTypeOfRevenue();
    }

    public LiveData<List<TypeOfRevenue>> getAllTypeOfRevenue() {
        return mAllTypeOfRevenue;
    }
    public void insert(TypeOfRevenue typeOfRevenue){
        mTypeOfRevenueRepository.insert(typeOfRevenue);
    }

    public void delete(TypeOfRevenue typeOfRevenue){
        mTypeOfRevenueRepository.delete((typeOfRevenue));
    }
    public void update(TypeOfRevenue typeOfRevenue){
        mTypeOfRevenueRepository.update(typeOfRevenue);
    }
}