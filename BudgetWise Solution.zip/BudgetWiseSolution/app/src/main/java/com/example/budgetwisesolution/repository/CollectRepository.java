package com.example.budgetwisesolution.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.budgetwisesolution.dao.AppDatabase;
import com.example.budgetwisesolution.dao.CollectDao;
import com.example.budgetwisesolution.entity.Collect;

import java.util.List;

public class CollectRepository {
    private CollectDao mCollectDao;
    private LiveData<List<Collect>> mAllCollect;

    public CollectRepository(Application application) {
        this.mCollectDao = AppDatabase.getDatabase(application).collectDao();
        mAllCollect = mCollectDao.findAll();
    }

    public LiveData<List<Collect>> getAllCollect() {
        return mAllCollect;
    }
    public void insert(Collect collect){
        new InsertAsyncTask(mCollectDao).execute(collect);
    }
    public void delete(Collect collect){
        new DeleteAsyncTask(mCollectDao).execute(collect);
    }
    public void update(Collect collect){
        new UpdateAsyncTask(mCollectDao).execute(collect);
    }
    class UpdateAsyncTask extends AsyncTask<Collect, Void, Void>{
        private CollectDao mCollectDao;
        public UpdateAsyncTask(CollectDao collectDao){
            this.mCollectDao = collectDao;
        }
        @Override
        protected Void doInBackground(Collect... collects) {
            mCollectDao.update(collects[0]);
            return null;
        }
    }
    class InsertAsyncTask extends AsyncTask<Collect, Void, Void>{
        private CollectDao mCollectDao;
        public InsertAsyncTask(CollectDao collectDao){
            this.mCollectDao = collectDao;
        }
        @Override
        protected Void doInBackground(Collect... collects) {
            mCollectDao.insert(collects[0]);
            return null;
        }
    }

    class DeleteAsyncTask extends AsyncTask<Collect, Void, Void>{
        private CollectDao mCollectDao;
        public DeleteAsyncTask(CollectDao collectDao){
            this.mCollectDao = collectDao;
        }
        @Override
        protected Void doInBackground(Collect... collects) {
            mCollectDao.delete(collects[0]);
            return null;
        }
    }
}
